﻿using System;

namespace $safeprojectname$
{
	public class $safeprojectname$ : Daniel15.Sharpamp.GeneralPlugin
	{
		public override string Name
		{
			get { return "$safeprojectname$"; }
		}

		public override void Initialize()
		{
			// TODO: Put your initialization code here
			return;
		}
	    public override void Config()
		{
			// TODO: Put your configuration code here
			return;
		}
		// Using a Quit() method here is supported, but there is not a need to add it, as the Plugin Wrapper will take care of that process by default
	}
}
