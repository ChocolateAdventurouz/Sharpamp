﻿using System;

namespace $safeprojectname$
{
	public class $safeprojectname$ : Daniel15.Sharpamp.GeneralPlugin
	{
		public override string Name
		{
			get { return "$safeprojectname$"; }
		}

		public override void Initialize()
		{
			// TODO: Put your initialization code here
			return;
		}
	    public override void Config()
		{
			// TODO: Put your configuration code here
			return;
		}
	}
}
